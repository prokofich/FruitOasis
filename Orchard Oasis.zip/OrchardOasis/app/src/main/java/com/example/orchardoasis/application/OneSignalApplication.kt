package com.example.orchardoasis.application

import android.app.Application
import android.content.SharedPreferences
import android.preference.PreferenceManager
import com.example.orchardoasis.model.constant.ONESIGNAL_APP_ID
import com.example.orchardoasis.model.extensions.createAndSaveUserId
import com.example.orchardoasis.model.extensions.getUserId
import com.onesignal.OneSignal

class OneSignalApplication:Application() {

    override fun onCreate() {
        super.onCreate()

        val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)

        if(sharedPreferences.getUserId()==""){
            sharedPreferences.createAndSaveUserId() // генерация и сохранение кастомного USER ID
        }

        // инициализация OneSignal
        OneSignal.setAppId(ONESIGNAL_APP_ID)
        OneSignal.initWithContext(this)
        OneSignal.setExternalUserId(sharedPreferences.getUserId())
        OneSignal.promptForPushNotifications()

    }

}