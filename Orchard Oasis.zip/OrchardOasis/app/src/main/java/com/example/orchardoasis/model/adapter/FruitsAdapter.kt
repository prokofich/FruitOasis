package com.example.orchardoasis.model.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.orchardoasis.R
import com.example.orchardoasis.model.constant.CHERRY
import com.example.orchardoasis.model.constant.DIAMOND
import com.example.orchardoasis.model.constant.LEMON
import com.example.orchardoasis.model.constant.LOSS
import com.example.orchardoasis.model.constant.QUESTION
import com.example.orchardoasis.model.constant.WIN

class FruitsAdapter(private val context: Context,private val interfaceGame:GameOver): RecyclerView.Adapter<FruitsAdapter.FruitsViewHolder>() {

    private var listFruits = emptyList<String>()
    private var listFruits2 = emptyList<String>()
    private var mainFruit = ""
    private var countMainFruit = 0
    private var countCorrectAnswers = 0
    private var blockFruits = true
    class FruitsViewHolder(view: View):RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FruitsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_rv,parent,false)
        return FruitsViewHolder(view)
    }

    override fun getItemCount(): Int {
        return listFruits.size
    }

    override fun onBindViewHolder(holder: FruitsViewHolder, position: Int) {
        val imageView = holder.itemView.findViewById<ImageView>(R.id.id_item_rv_iv)
        when(listFruits[position]){
            QUESTION -> { imageView.load(R.drawable.znak_question) }
            LEMON    -> { imageView.load(R.drawable.lemon) }
            CHERRY   -> { imageView.load(R.drawable.cherry) }
            DIAMOND  -> { imageView.load(R.drawable.diamand) }
        }
    }

    override fun onViewAttachedToWindow(holder: FruitsViewHolder) {
        super.onViewAttachedToWindow(holder)

        val imageView = holder.itemView.findViewById<ImageView>(R.id.id_item_rv_iv)

        holder.itemView.setOnClickListener {
            if(!blockFruits){
                if(listFruits[holder.adapterPosition] == QUESTION){
                    when(listFruits2[holder.adapterPosition]){
                        LEMON   -> { imageView.load(R.drawable.lemon) }
                        CHERRY  -> { imageView.load(R.drawable.cherry) }
                        DIAMOND -> { imageView.load(R.drawable.diamand) }
                    }
                    if(listFruits2[holder.adapterPosition]==mainFruit){
                        Toast.makeText(context,"correct!",Toast.LENGTH_SHORT).show()
                        countCorrectAnswers+=1
                        if(countCorrectAnswers==countMainFruit){
                            interfaceGame.finish(WIN) // победа
                        }
                    }else{
                        interfaceGame.finish(LOSS) // поражение
                    }
                }
            }
        }

    }

    @SuppressLint("NotifyDataSetChanged")
    fun setList(list:List<String>){
        listFruits = list
        listFruits2 = list
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setListQuestion(list:List<String>){
        listFruits = list
        notifyDataSetChanged()
    }

    // установка выбранного фрукта
    fun setMainFruit(fruit:String){
        mainFruit = fruit
    }

    // закрытие/открытие возможности нажатия на элементы
    fun setBlock(flag:Boolean){
        blockFruits = flag
    }

    // установка количества правильных элементов
    fun setCountMainFruit(count:Int){
        countMainFruit = count
    }

}