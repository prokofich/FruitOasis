package com.example.orchardoasis.model.adapter

interface GameOver {

    fun finish(result:String)

}