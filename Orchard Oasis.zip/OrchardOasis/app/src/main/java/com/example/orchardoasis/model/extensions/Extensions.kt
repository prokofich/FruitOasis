package com.example.orchardoasis.model.extensions

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.telephony.TelephonyManager
import android.view.View
import android.webkit.WebView
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.orchardoasis.model.constant.ADVERTISING_ID
import com.example.orchardoasis.model.constant.COUNT_START_APPLICATION
import com.example.orchardoasis.model.constant.LAST_URL_IN_WEB
import com.example.orchardoasis.model.constant.MAIN_ATTRIBUTE
import com.example.orchardoasis.model.constant.MAIN_URL_IN_WEB
import com.example.orchardoasis.model.constant.STATUS_INSTALLATION
import com.example.orchardoasis.model.constant.USER_ID
import com.example.orchardoasis.model.repository.Repository
import java.util.UUID

// функция расширения для вставки параметров в сырую ссылку
fun String.setValueInRawLink(listName:List<String>?,packageName:String,context: Context):String{
    val repository = Repository(context)
    if(listName==null){
        return this +
                "/1238sdfu8?sub_id_1=none" +
                "&sub_id_2=none" +
                "&sub_id_3=none" +
                "&sub_id_4=none" +
                "&sub_id_5=none" +
                "&offer_name=none" +
                "&client_id=none" +
                "&bundle=$packageName" +
                "&razrab=razrab10" +
                "&appsflyer_id=${repository.getUserId()}" +
                "&advertising_id=${repository.getAdvertisingId()}" +
                "&appsdv=none"
    }else{
        var newLink = "$this/1238sdfu8?"
        for(i in 0..<(listName.size)-2){
            newLink+="sub_id_${i+1}=${listName[i+2]}&"
        }
        newLink = newLink.removeSuffix("&")
        newLink+="&offer_name=${listName[1]}&client_id=${listName[0]}&bundle=$packageName&razrab=razrab10&appsflyer_id=${repository.getUserId()}" +
                "&advertising_id=${repository.getAdvertisingId()}&appsdv=none"
        return newLink
    }
}

// функция добавления ссылки и показа первого WebView
fun WebView.loadUrlAndShowFirstWebView(context: Context,webArray:MutableList<WebView>,constLayout:ConstraintLayout){
    this.loadUrl(Repository(context).getMainUrl()) // добавление полученной ссылки с параметрами в первый WebView
    webArray.add(this)                             // добавление первого WebView в список
    constLayout.addView(this)                 // добавление первого WebView на экран
}

// функция добавления ссылки и показа старого WebView
fun WebView.loadUrlAndShowOldWebView(context: Context,webArray:MutableList<WebView>,constLayout:ConstraintLayout){
    this.loadUrl(Repository(context).getLastUrl()) // добавление полученной ссылки с параметрами в старый WebView
    webArray.add(this)                             // добавление старого WebView в список
    constLayout.addView(this)                 // добавление старого WebView на экран
}

fun WebView.loadUrlAndShowNewWebView(url:String,webArray:MutableList<WebView>,constLayout:ConstraintLayout){
    this.loadUrl(url)                              // добавление ссылки в новый WebView
    webArray.add(this)                             // добавление нового WebView в список
    constLayout.addView(this)                 // добавление нового WebView на экран
}

fun WebView.saveUrl(){

}

// функция сохранения последнего URL адреса
fun SharedPreferences.saveLastUrl(url:String){
    this.edit()
        .putString(LAST_URL_IN_WEB,url)
        .apply()
}

// функция сохранения первого полученного URL адреса
fun SharedPreferences.saveMainUrl(url:String){
    this.edit()
        .putString(MAIN_URL_IN_WEB,url)
        .apply()
}

// функция сохранения главного аттрибута
fun SharedPreferences.saveMainAttribute(nameCompany:String){
    this.edit()
        .putString(MAIN_ATTRIBUTE,nameCompany)
        .apply()
}

// функция сохранения статуса установки
fun SharedPreferences.saveStatusInstallation(status:String){
    this.edit()
        .putString(STATUS_INSTALLATION,status)
        .apply()
}

// функция обновления количества запусков приложения
fun SharedPreferences.updateCountStartApplication(){
    this.edit()
        .putInt(COUNT_START_APPLICATION,getCountStartApplication()+1)
        .apply()
}

// функция получения последнего url адреса
fun SharedPreferences.getLastUrl(): String{
    return this.getString(LAST_URL_IN_WEB,"").toString()
}

// функция получения главного аттрибута
fun SharedPreferences.getMainAttribute(): String{
    return this.getString(MAIN_ATTRIBUTE,"").toString()
}

//функция получения iso кода симки устройства
fun SharedPreferences.getIsoCodeInPhone(appContext: Context): String {
    val telephonyManager = appContext.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    return telephonyManager.simCountryIso.toString()
}

//функция получения первого полученного url адреса
fun SharedPreferences.getMainUrl(): String {
    return this.getString(MAIN_URL_IN_WEB,"").toString()
}

//функция получения количества запусков приложения
fun SharedPreferences.getCountStartApplication(): Int {
    return this.getInt(COUNT_START_APPLICATION,0)
}

//функция проверки первого запуска приложения
fun SharedPreferences.checkFirstStartApplication(): Boolean {
    return getCountStartApplication()==0
}

//функция создания кастомного ID юзера для OneSignal
fun SharedPreferences.createAndSaveUserId(){
    val userId = UUID.randomUUID().toString()
    this.edit()
        .putString(USER_ID,userId)
        .apply()
}

//функция получения кастомного ID юзера
fun SharedPreferences.getUserId():String{
    return this.getString(USER_ID,"").toString()
}

//функция получения advertising id
fun SharedPreferences.getAdvertisingId(): String {
    return this.getString(ADVERTISING_ID,"").toString()
}

//функция сохранения advertising id
fun SharedPreferences.saveAdvertisingId(id:String){
    this.edit()
        .putString(ADVERTISING_ID,id)
        .apply()
}



