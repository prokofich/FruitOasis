package com.example.orchardoasis.view.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.view.WindowManager
import android.webkit.ValueCallback
import android.webkit.WebBackForwardList
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.Toast
import androidx.core.view.size
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.amplitude.api.Amplitude
import com.amplitude.api.AmplitudeClient
import com.example.orchardoasis.R
import com.example.orchardoasis.databinding.ActivityGameBinding
import com.example.orchardoasis.model.constant.AMPLITUDE_API_KEY
import com.example.orchardoasis.model.constant.FOR_GAME
import com.example.orchardoasis.model.constant.FOR_WEBVIEW
import com.example.orchardoasis.model.constant.FOR_WEBVIEW_REPEAT
import com.example.orchardoasis.model.constant.GAME
import com.example.orchardoasis.model.constant.START_TIME
import com.example.orchardoasis.model.constant.TYPE
import com.example.orchardoasis.model.databaseFirestore.Firestore
import com.example.orchardoasis.model.extensions.getMainUrl
import com.example.orchardoasis.model.extensions.loadUrlAndShowFirstWebView
import com.example.orchardoasis.model.extensions.loadUrlAndShowNewWebView
import com.example.orchardoasis.model.extensions.loadUrlAndShowOldWebView
import com.example.orchardoasis.model.extensions.saveLastUrl
import com.example.orchardoasis.model.repository.Repository
import com.example.orchardoasis.model.webview.CreatorWebView
import com.example.orchardoasis.view.interfaceActivity.InterfaceGameActivity
import com.google.firebase.firestore.FirebaseFirestore

class GameActivity : AppCompatActivity(),InterfaceGameActivity {

    private lateinit var binding: ActivityGameBinding
    private lateinit var webView: WebView
    private lateinit var creatorWebView: CreatorWebView
    private lateinit var amplitude: AmplitudeClient
    lateinit var navController: NavController

    private var startTimer:Long = 0
    private var webViewArray = mutableListOf<WebView>()

    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserResultCode = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        GAME = this
        navController = Navigation.findNavController(this,R.id.id_nav_host)

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        startTimer = intent.getLongExtra(START_TIME,0)

        amplitude = Amplitude.getInstance().initialize(applicationContext, AMPLITUDE_API_KEY)
        creatorWebView = CreatorWebView(this,this,window,amplitude,startTimer)

        // загрузка состояния WebView после смены конфигурации
        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        }

        // первый показ WebView
        if(intent.getStringExtra(TYPE) == FOR_WEBVIEW){
            webView = creatorWebView.createWebView() // создание первого WebView\
            webView.loadUrlAndShowFirstWebView(this,webViewArray,binding.idGame) // загрузка ссылки + показ на экране
        }

        // повторный показ WebView
        if(intent.getStringExtra(TYPE) == FOR_WEBVIEW_REPEAT){
            webView = creatorWebView.createWebView() // создание старого WebView
            webView.loadUrlAndShowOldWebView(this,webViewArray,binding.idGame)   // загрузка ссылки + показ на экране
        }

        // проверка на переход для игры
        if(intent.getStringExtra(TYPE) == FOR_GAME){
            amplitude.logEvent("open_main") // отправка ивента
        }

    }

    //обработка перехода назад + возможное закрытие
    @SuppressLint("MissingSuperCall")
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if(intent.getStringExtra(TYPE) != FOR_GAME){
            val currentWebView = webViewArray.lastOrNull() // текущий WebView
            if (webViewArray.size > 1) {
                if (currentWebView!!.canGoBack()) {
                    val history: WebBackForwardList = currentWebView.copyBackForwardList()
                    val previousUrl: String = history.getItemAtIndex(history.currentIndex - 1).url
                    val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
                    sharedPreferences.saveLastUrl(previousUrl)
                    currentWebView.goBack() // переход по ссылке назад в текущем WebView
                }else{
                    val index = webViewArray.indexOf(currentWebView)

                    val previousWebView = webViewArray[webView.size-2]

                    val history: WebBackForwardList = previousWebView.copyBackForwardList()
                    val previousUrl: String = history.getItemAtIndex(history.currentIndex).url
                    val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
                    sharedPreferences.saveLastUrl(previousUrl)

                    webViewArray.removeAt(index) // удаляем текущий WebView из списка
                    binding.idGame.removeView(currentWebView) // удаляем текущий WebView с экрана
                }
            } else {
                if (currentWebView!!.canGoBack()) {
                    val history: WebBackForwardList = currentWebView.copyBackForwardList()
                    val previousUrl: String = history.getItemAtIndex(history.currentIndex - 1).url
                    val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
                    sharedPreferences.saveLastUrl(previousUrl)
                    currentWebView.goBack() // переход по ссылке назад в текущем WebView
                }else{
                    finishAffinity()
                }
            }
        }
    }

    override fun goActivityForResult(intent: Intent, code: Int) {
        startActivityForResult(intent, code)
    }

    override fun setHorizontalScreen() {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    override fun setVerticalScreen() {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    // создание нового WebView (запрос на открытие нового окна)
    override fun showNewWindow(url: String) {
        val newWebView = creatorWebView.createWebView()
        newWebView.loadUrlAndShowNewWebView(url,webViewArray,binding.idGame) // загрузка ссылки + показ на экране
    }

    //сохранение состояния при изменении конфигурации
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserResultCode) {
            if (fileUploadCallback != null) {
                val results = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                fileUploadCallback!!.onReceiveValue(results)
                fileUploadCallback = null
            }
        }
    }

}