package com.example.orchardoasis.view.interfaceActivity

import android.content.Intent

interface InterfaceGameActivity {

    fun goActivityForResult(intent: Intent, code:Int) // функция запуска activity
    fun setHorizontalScreen()                         // установка горизонтального режима экрана
    fun setVerticalScreen()                           // установка портретного режима экрана
    fun showNewWindow(url: String)                    // показ нового окна

}