package com.example.orchardoasis.view.interfaceActivity

interface InterfaceSplashActivity {

    fun goToStubApplication(type:String) // переход на заглушку

}