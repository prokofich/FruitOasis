package com.example.orchardoasis.an1

import android.app.Application
import android.content.SharedPreferences
import android.preference.PreferenceManager
import android.provider.Settings
import com.example.orchardoasis.mod.ct111.ONESIGNAL_APP_ID
import com.example.orchardoasis.mod.es.crtndSvsrId
import com.example.orchardoasis.mod.es.gtsrd
import com.onesignal.OneSignal

class OnOn:Application() {

    override fun onCreate() {
        super.onCreate()

        val sp: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        if(sp.gtsrd()==""){
            sp.crtndSvsrId() // генерация и сохранение кастомного USER ID
        }

    }

}