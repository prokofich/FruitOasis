package com.example.orchardoasis.mod.ar3

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.orchardoasis.R
import com.example.orchardoasis.mod.ct111.CHERRY
import com.example.orchardoasis.mod.ct111.DIAMOND
import com.example.orchardoasis.mod.ct111.LEMON
import com.example.orchardoasis.mod.ct111.LOSS
import com.example.orchardoasis.mod.ct111.QUESTION
import com.example.orchardoasis.mod.ct111.WIN

class fAdr(private val context: Context, private val interfaceGame:gr): RecyclerView.Adapter<fAdr.FruitsViewHolder>() {

    private var lstFrts = emptyList<String>()
    private var lstFrts2 = emptyList<String>()
    private var mnFrt = ""
    private var cntMnFrt = 0
    private var cntCrrctnswrs = 0
    private var blckFrts = true
    class FruitsViewHolder(view: View):RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FruitsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.vt_mit,parent,false)
        return FruitsViewHolder(view)
    }

    override fun getItemCount(): Int {
        return lstFrts.size
    }

    override fun onBindViewHolder(holder: FruitsViewHolder, position: Int) {
        val imageView = holder.itemView.findViewById<ImageView>(R.id.id_item_rv_iv)
        when(lstFrts[position]){
            QUESTION -> { imageView.load(R.drawable.a) }
            LEMON    -> { imageView.load(R.drawable.f) }
            CHERRY   -> { imageView.load(R.drawable.g) }
            DIAMOND  -> { imageView.load(R.drawable.s) }
        }
    }

    override fun onViewAttachedToWindow(holder: FruitsViewHolder) {
        super.onViewAttachedToWindow(holder)

        val imageView = holder.itemView.findViewById<ImageView>(R.id.id_item_rv_iv)

        holder.itemView.setOnClickListener {
            if(!blckFrts){
                if(lstFrts[holder.adapterPosition] == QUESTION){
                    when(lstFrts2[holder.adapterPosition]){
                        LEMON   -> { imageView.load(R.drawable.f) }
                        CHERRY  -> { imageView.load(R.drawable.g) }
                        DIAMOND -> { imageView.load(R.drawable.s) }
                    }
                    if(lstFrts2[holder.adapterPosition]==mnFrt){
                        Toast.makeText(context,"correct!",Toast.LENGTH_SHORT).show()
                        cntCrrctnswrs+=1
                        if(cntCrrctnswrs==cntMnFrt){
                            interfaceGame.fnsh(WIN) // победа
                        }
                    }else{
                        interfaceGame.fnsh(LOSS) // поражение
                    }
                }
            }
        }

    }

    @SuppressLint("NotifyDataSetChanged")
    fun stLst(lst:List<String>){
        lstFrts = lst
        lstFrts2 = lst
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun stLstQstn(lst:List<String>){
        lstFrts = lst
        notifyDataSetChanged()
    }

    // установка выбранного фрукта
    fun stMnFrt(frt:String){
        mnFrt = frt
    }

    // закрытие/открытие возможности нажатия на элементы
    fun stBlck(flg:Boolean){
        blckFrts = flg
    }

    // установка количества правильных элементов
    fun stCntMnFrt(cnt:Int){
        cntMnFrt = cnt
    }

}