package com.example.orchardoasis.mod.ar3

interface gr {

    fun fnsh(rslt:String)

}