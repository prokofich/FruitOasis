package com.example.orchardoasis.mod.ry

import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager
import com.example.orchardoasis.mod.ct111.ADVERTISING_ID
import com.example.orchardoasis.mod.ct111.LAST_URL_IN_WEB
import com.example.orchardoasis.mod.ct111.MAIN_URL_IN_WEB
import com.example.orchardoasis.mod.ct111.USER_ID

class rEpOrchardOAs(context: Context){

    @Suppress("DEPRECATION")
    //использование SharedPreferences в качестве базы данных
    private val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)

    //функция получения последнего url адреса
    fun getLastUrl(): String {
        return sharedPreferences.getString(LAST_URL_IN_WEB,"").toString()
    }

    //функция получения первого полученного url адреса
    fun getMainUrl(): String {
        return sharedPreferences.getString(MAIN_URL_IN_WEB,"").toString()
    }

    //функция получения кастомного ID юзера
    fun getUserId():String{
        return sharedPreferences.getString(USER_ID,"").toString()
    }

    //функция получения advertising id
    fun getAdvertisingId(): String {
        return sharedPreferences.getString(ADVERTISING_ID,"").toString()
    }

}