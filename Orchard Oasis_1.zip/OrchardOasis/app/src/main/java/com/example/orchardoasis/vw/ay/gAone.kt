package com.example.orchardoasis.vw.ay

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Rect
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.provider.Settings
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebBackForwardList
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.fragment.NavHostFragment
import com.amplitude.api.Amplitude
import com.amplitude.api.AmplitudeClient
import com.example.orchardoasis.R
import com.example.orchardoasis.databinding.CatEmagBinding
import com.example.orchardoasis.mod.ct111.AMPLITUDE_API_KEY
import com.example.orchardoasis.mod.ct111.FOR_GAME
import com.example.orchardoasis.mod.ct111.FOR_WEBVIEW
import com.example.orchardoasis.mod.ct111.FOR_WEBVIEW_REPEAT
import com.example.orchardoasis.mod.ct111.GAME
import com.example.orchardoasis.mod.ct111.ONESIGNAL_APP_ID
import com.example.orchardoasis.mod.ct111.START_TIME
import com.example.orchardoasis.mod.ct111.TYPE
import com.example.orchardoasis.mod.es.gtsrd
import com.example.orchardoasis.mod.es.ldUrlndShwFrstWbVw
import com.example.orchardoasis.mod.es.ldUrlndShwldWbVw
import com.example.orchardoasis.mod.es.ldrlndShwNwWbVw
import com.example.orchardoasis.mod.es.svLstrl
import com.example.orchardoasis.mod.ww.crww
import com.example.orchardoasis.vw.fs.muft
import com.example.orchardoasis.vw.ia.iTnMagtiV
import com.onesignal.OneSignal

class gAone : AppCompatActivity(),iTnMagtiV {

    private lateinit var bndng: CatEmagBinding
    private lateinit var wbVw: WebView
    private lateinit var crtrWbVw: crww
    private lateinit var mpltd: AmplitudeClient
    lateinit var nvCntrllr: NavController

    private var strtTmr:Long = 0
    private var wbVwrr = mutableListOf<WebView>()

    private lateinit var sp:SharedPreferences

    private var flpldCllbck: ValueCallback<Array<Uri>>? = null
    private val flChsrRsltCd = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bndng = CatEmagBinding.inflate(layoutInflater)
        val view = bndng.root
        setContentView(view)

        GAME = this
        nvCntrllr = Navigation.findNavController(this,R.id.id_nav_host)

        sp = PreferenceManager.getDefaultSharedPreferences(this)

        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)

        strtTmr = intent.getLongExtra(START_TIME,0)

        mpltd = Amplitude.getInstance().initialize(applicationContext, AMPLITUDE_API_KEY)
        crtrWbVw = crww(this,this,window,mpltd,strtTmr)

        wbVw = WebView(this) // далее сюда запишется правильный экземпляр

        // загрузка состояния WebView после смены конфигурации
        if (savedInstanceState != null) {
            wbVw.restoreState(savedInstanceState)
        }

        // первый показ WebView
        if(intent.getStringExtra(TYPE) == FOR_WEBVIEW){
            initOneSignal() // инициализация OneSignal
            val navHostFragment = supportFragmentManager.findFragmentById(R.id.id_nav_host) as NavHostFragment
            val menuFragment = navHostFragment.childFragmentManager.fragments[0] as muft
            menuFragment.hideContent() // скрытие контента
            wbVw = crtrWbVw.createWebView() // создание первого WebView\
            wbVw.ldUrlndShwFrstWbVw(this,wbVwrr,bndng.idGame) // загрузка ссылки + показ на экране
        }

        // повторный показ WebView
        if(intent.getStringExtra(TYPE) == FOR_WEBVIEW_REPEAT){
            initOneSignal() // инициализация OneSignal
            val navHostFragment = supportFragmentManager.findFragmentById(R.id.id_nav_host) as NavHostFragment
            val menuFragment = navHostFragment.childFragmentManager.fragments[0] as muft
            menuFragment.hideContent() // скрытие контента
            wbVw = crtrWbVw.createWebView() // создание старого WebView
            wbVw.ldUrlndShwldWbVw(this,wbVwrr,bndng.idGame)   // загрузка ссылки + показ на экране
        }

        // проверка на переход для игры
        if(intent.getStringExtra(TYPE) == FOR_GAME){
            mpltd.logEvent("open_main") // отправка ивента
        }

    }

    //обработка перехода назад + возможное закрытие
    @SuppressLint("MissingSuperCall")
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if(intent.getStringExtra(TYPE) != FOR_GAME){

            val currentWebView = wbVwrr.lastOrNull() // текущий WebView

            if (wbVwrr.size > 1) {
                if (currentWebView!!.canGoBack()) {

                    savePreviousUrl(currentWebView) // сохранение ссылки при табе назад
                    currentWebView.goBack() // переход по ссылке назад в текущем WebView

                }else{

                    val index = wbVwrr.indexOf(currentWebView)
                    val previousWebView = wbVwrr[wbVwrr.size-2]
                    saveUrlInPreviousWebView(previousWebView) // сохранение ссылки при табе назад
                    wbVwrr.removeAt(index) // удаляем текущий WebView из списка
                    bndng.idGame.removeView(currentWebView) // удаляем текущий WebView с экрана

                }
            } else {
                if (currentWebView!!.canGoBack()) {

                    savePreviousUrl(currentWebView) // сохранение ссылки при табе назад
                    currentWebView.goBack() // переход по ссылке назад в текущем WebView

                }else{

                    finishAffinity() // закрытие приложения

                }
            }
        }
    }

    override fun gctvtFrRslt(ntnt: Intent, cd: Int,cb:ValueCallback<Array<Uri>>?) {
        flpldCllbck = cb
        startActivityForResult(ntnt, cd)
    }

    override fun stHrzntlScrn() {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    override fun stVrtclScrn() {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    // создание нового WebView (запрос на открытие нового окна)
    override fun shwNwWndw(rl: String) {
        val nwWbVw = crtrWbVw.createWebView()
        nwWbVw.ldrlndShwNwWbVw(rl,wbVwrr,bndng.idGame) // загрузка ссылки + показ на экране
    }

    override fun showToast(str: String) {
        Toast.makeText(this,str,Toast.LENGTH_SHORT).show()
    }

    /*override fun registerPerm(permissionRequest: PermissionRequest) {
        val requestPermissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
                if (isGranted) {
                    // Разрешение получено, предоставляем разрешение камеры
                    permissionRequest.grant(permissionRequest.resources)
                } else {
                    // Разрешение не получено, отклоняем запрос
                    permissionRequest.deny()
                }
            }
        requestPermissionLauncher.launch(android.Manifest.permission.CAMERA)
    }*/

    //сохранение состояния при изменении конфигурации
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        wbVw.saveState(outState)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1) {
            if (flpldCllbck != null) {
                val results = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                crtrWbVw.fileUploadCallback!!.onReceiveValue(results)
                crtrWbVw.fileUploadCallback = null
            }
        }
    }

    // функция инициализации OneSignal
    private fun initOneSignal(){
        if(Settings.Global.getInt(applicationContext.contentResolver,"adb_enabled",0)==0){
            OneSignal.setAppId(ONESIGNAL_APP_ID)
            OneSignal.initWithContext(this)
            OneSignal.setExternalUserId(sp.gtsrd())
        }
    }

    // функция сохранения ссылки при табе назад
    private fun savePreviousUrl(webView:WebView){
        val history: WebBackForwardList = webView.copyBackForwardList()
        val previousUrl: String = history.getItemAtIndex(history.currentIndex - 1).url
        val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        sharedPreferences.svLstrl(previousUrl)
    }

    // функция сохранения ссылки при табе назад
    private fun saveUrlInPreviousWebView(webView:WebView){
        val history: WebBackForwardList = webView.copyBackForwardList()
        val previousUrl: String = history.getItemAtIndex(history.currentIndex).url
        val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        sharedPreferences.svLstrl(previousUrl)
    }

}