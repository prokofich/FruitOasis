package com.example.orchardoasis.vw.fs

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import com.example.orchardoasis.R
import android.view.ViewGroup
import com.example.orchardoasis.databinding.CompBinding
import com.example.orchardoasis.mod.ct111.COMPLEXITY
import com.example.orchardoasis.mod.ct111.EASY
import com.example.orchardoasis.mod.ct111.GAME
import com.example.orchardoasis.mod.ct111.HARD
import com.example.orchardoasis.mod.ct111.MIDDLE

class clft : Fragment() {

    private var bndng: CompBinding? = null
    private lateinit var bndlFrGm:Bundle

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        bndng = CompBinding.inflate(inflater,container,false)
        return bndng?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // переход обратно в меню
        bndng!!.idCompButtonBack.setOnClickListener {
            GAME.nvCntrllr.navigate(R.id.action_complexityLevelFragment_to_menuFragment)
        }

        // выбор легкого уровня
        bndng!!.idCompButtonEasy.setOnClickListener {
            bndlFrGm = Bundle()
            bndlFrGm.putInt(COMPLEXITY, EASY)
            GAME.nvCntrllr.navigate(R.id.action_complexityLevelFragment_to_gameFragment,bndlFrGm)
        }

        // выбор среднего уровня
        bndng!!.idCompButtonMiddle.setOnClickListener {
            bndlFrGm = Bundle()
            bndlFrGm.putInt(COMPLEXITY, MIDDLE)
            GAME.nvCntrllr.navigate(R.id.action_complexityLevelFragment_to_gameFragment,bndlFrGm)
        }

        // выбор сложного уровня
        bndng!!.idCompButtonHard.setOnClickListener {
            bndlFrGm = Bundle()
            bndlFrGm.putInt(COMPLEXITY, HARD)
            GAME.nvCntrllr.navigate(R.id.action_complexityLevelFragment_to_gameFragment,bndlFrGm)
        }


    }

    override fun onDestroyView() {
        super.onDestroyView()
        bndng = null
    }


}