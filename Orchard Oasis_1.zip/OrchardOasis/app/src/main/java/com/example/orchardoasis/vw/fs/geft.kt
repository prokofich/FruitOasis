package com.example.orchardoasis.vw.fs

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.orchardoasis.R
import androidx.core.view.isVisible
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.orchardoasis.databinding.GamTBinding
import com.example.orchardoasis.mod.ar3.fAdr
import com.example.orchardoasis.mod.ar3.gr
import com.example.orchardoasis.mod.ct111.CHERRY
import com.example.orchardoasis.mod.ct111.COMPLEXITY
import com.example.orchardoasis.mod.ct111.DIAMOND
import com.example.orchardoasis.mod.ct111.GAME
import com.example.orchardoasis.mod.ct111.LEMON
import com.example.orchardoasis.mod.ct111.WIN
import com.example.orchardoasis.mod.ct111.listAllFruit
import com.example.orchardoasis.mod.ct111.listFruitsForGame
import com.example.orchardoasis.mod.ct111.listQuestionsForGame
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class geft : Fragment(),gr {

    private var cntSc:Int = 0
    private var cntCrrctnswrs = 0
    private var bndng: GamTBinding? = null
    private var mnFrt = ""
    private var jb:Job = Job()

    private lateinit var rcclrVw: RecyclerView
    private lateinit var dptrFrts: fAdr

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        bndng = GamTBinding.inflate(inflater,container,false)
        return bndng?.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        cntSc = requireArguments().getInt(COMPLEXITY) // 6,5 или 4 секунды на запоминание
        mnFrt = listAllFruit.shuffled()[1] // выбранный случайный фрукт
        stCntCrrctnswrs()

        // привязка к recyclerView
        rcclrVw = bndng!!.idGameRv
        dptrFrts = fAdr(requireContext(),this)
        rcclrVw.layoutManager = GridLayoutManager(requireContext(),4)
        rcclrVw.adapter = dptrFrts
        dptrFrts.stLstQstn(listQuestionsForGame) // закрытие показа фруктов

        // начать игру
        bndng!!.idGameButtonGo.setOnClickListener {
            jb = CoroutineScope(Dispatchers.Main).launch {
                strtGm()
                shwMnFrt()
            }
        }

        // закончить игру и выйти в меню
        bndng!!.idGameButtonFinish.setOnClickListener {
            if(jb.isActive){
                jb.cancel()
            }
            GAME.nvCntrllr.navigate(R.id.action_gameFragment_to_menuFragment)
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        bndng = null
    }

    @SuppressLint("SetTextI18n")
    private suspend fun strtGm(){
        bndng!!.idGameTvTimer.isVisible = true
        bndng!!.idGameButtonGo.isVisible = false
        bndng!!.idGameButtonFinish.isVisible = true
        dptrFrts.stLst(listFruitsForGame.shuffled())
        for (i in cntSc downTo 0){
            bndng!!.idGameTvTimer.text = "$i seconds"
            delay(1000)
        }
        dptrFrts.stLstQstn(listQuestionsForGame)
        bndng!!.idGameTvTimer.isVisible = false
        bndng!!.idGameCsMainFruit.isVisible = true
        dptrFrts.stMnFrt(mnFrt)
        dptrFrts.stCntMnFrt(cntCrrctnswrs)
        dptrFrts.stBlck(false)
    }

    private fun shwMnFrt(){
        when(mnFrt){
            LEMON   -> { bndng!!.idGameIvMainFruit.load(R.drawable.f) }
            CHERRY  -> { bndng!!.idGameIvMainFruit.load(R.drawable.g) }
            DIAMOND -> { bndng!!.idGameIvMainFruit.load(R.drawable.s) }
        }
    }

    private fun stCntCrrctnswrs(){
        when(mnFrt){
            LEMON   -> { cntCrrctnswrs = 5 }
            CHERRY  -> { cntCrrctnswrs = 5 }
            DIAMOND -> { cntCrrctnswrs = 6 }
        }
    }

    override fun fnsh(rslt: String) {
        val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
        builder.setTitle("GAME OVER")

        if(rslt == WIN){
            builder.setMessage("Congratulations! You've won!")
        }else{
            builder.setMessage("unfortunately you lost")
        }

        builder.setPositiveButton("start again") { dialog, which ->
            GAME.nvCntrllr.navigate(R.id.action_gameFragment_to_complexityLevelFragment)
        }

        builder.setNegativeButton("go to menu") { dialog, which ->
            GAME.nvCntrllr.navigate(R.id.action_gameFragment_to_menuFragment)
        }

        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

}