package com.example.orchardoasis.vw.fs

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.widget.Toast
import androidx.core.view.isVisible
import com.example.orchardoasis.R
import com.example.orchardoasis.databinding.EnmGmBinding
import com.example.orchardoasis.mod.ct111.GAME

class muft : Fragment() {

    private var bndng:EnmGmBinding? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        bndng = EnmGmBinding.inflate(inflater,container,false)
        activity?.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        return bndng?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // выход из игры
        bndng!!.idMenuButtonExit.setOnClickListener {
            GAME.finishAffinity()
        }

        // переход к правилам игры
        bndng!!.idMenuButtonRules.setOnClickListener {
            GAME.nvCntrllr.navigate(R.id.action_menuFragment_to_rulesFragment)
        }

        // переход к выбору сложности игры
        bndng!!.idMenuButtonPlay.setOnClickListener {
            GAME.nvCntrllr.navigate(R.id.action_menuFragment_to_complexityLevelFragment)
        }

    }

    // функция очистки биндинга
    override fun onDestroyView() {
        super.onDestroyView()
        bndng = null
    }

    // функция скрытия контента
    fun hideContent() {
        bndng!!.idMenuButtonExit.isVisible = false
        bndng!!.idMenuButtonPlay.isVisible = false
        bndng!!.idMenuTvTitle.isVisible = false
        bndng!!.idMenuButtonRules.isVisible = false
    }
}