package com.example.orchardoasis.vw.ia

import android.content.Intent
import android.net.Uri
import android.webkit.PermissionRequest
import android.webkit.ValueCallback

interface iTnMagtiV {

    fun gctvtFrRslt(ntnt: Intent, cd:Int,cb: ValueCallback<Array<Uri>>?) // функция запуска activity
    fun stHrzntlScrn()                         // установка горизонтального режима экрана
    fun stVrtclScrn()                           // установка портретного режима экрана
    fun shwNwWndw(rl: String)                    // показ нового окна
    fun showToast(str:String)
    //fun registerPerm(permissionRequest: PermissionRequest)

}