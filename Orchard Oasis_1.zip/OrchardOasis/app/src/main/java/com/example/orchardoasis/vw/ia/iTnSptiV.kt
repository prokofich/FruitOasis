package com.example.orchardoasis.vw.ia

interface iTnSptiV {

    fun gTStbpplctn(tp:String) // переход на заглушку organic_url inorganic_url
    fun showLastWebView()      // переход на заглушку для показа последней сохраненной ссылки

}